import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-restful',
  templateUrl: './restful.component.html',
  styleUrls: ['./restful.component.css']
})
export class RestfulComponent implements OnInit {

  user: User;
  users: any;

  constructor(public loginService: LoginService) {
    this.user = new User();

    loginService.listUsers()
      .subscribe(res => {
        this.users = res;
      });
  }

  ngOnInit() {
  }

  addUser() {
    console.log("adding user: " + this.user);
    this.loginService.addUser(this.user)
      .subscribe(res => {
        this.users = res;
        //reset form
        this.user = new User();
      });
  }

  deleteUser(rowIndex) {
    console.log("deleting row: " + rowIndex);
    this.loginService.deleteUser(rowIndex)
      .subscribe(res => {
        this.users = res;
      });
  }
}
